#include "Fecha.h"
#include <iostream>
using namespace std;

Fecha::Fecha(int mes, int dia, int anio):mes(mes), dia(dia), anio(anio){
    if (mes < 1 || mes > 12) {
        mes = 1; 
    }
}
void Fecha::establecerMes(int mes){
    mes = mes;
}
void Fecha::establecerDia(int dia){
    dia = dia;
}
void Fecha::establecerAnio(int anio){
    anio = anio;
}
int Fecha::obtenerMes(){
    return mes;
}
int Fecha::obtenerDia(){
    return dia;
}
int Fecha::obtenerAnio(){
    return anio;
}
void Fecha::mostrarFecha(){
    cout << mes << "/" << dia << "/" << anio << endl;
}