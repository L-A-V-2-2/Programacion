#include <string>
class Factura
{
private:
    std::string numeroDePieza;
    std::string descripcionDePieza;
    int cantidad;
    int precio;
public:
    Factura(std::string, std::string, int, int);
    void establecerNumeroDePieza(std::string);
    void establecerDescripcionDePieza(std::string);
    void establecerCantidad(int);
    void establecerPrecio(int);
    
    std::string obtenerNumeroDePieza();
    std::string obtenerDescripcionDePieza();
    int obtenerCantidad();
    int obtenerPrecio();
    int obtenerMontoFactura();
};


