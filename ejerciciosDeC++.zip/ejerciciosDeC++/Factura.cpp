#include "Factura.h"
using namespace std;
Factura::Factura(string numero, string descripcion, int cantidad, int precio):numeroDePieza(numero), descripcionDePieza(descripcion), cantidad(cantidad), precio(precio){
    if (cantidad < 0) cantidad = 0;
    if (precio < 0) precio = 0;
}
void Factura::establecerNumeroDePieza(string numero){
    numeroDePieza = numero;
}
void Factura::establecerDescripcionDePieza(string descripcion){
    descripcion = descripcion;
}
void Factura::establecerCantidad(int cantidad){
    cantidad = (cantidad < 0) ? 0 : cantidad;
}
void Factura::establecerPrecio(int precio){
    precio = (precio < 0) ? 0 : precio;
}
string Factura::obtenerNumeroDePieza(){
    return numeroDePieza;
}
string Factura::obtenerDescripcionDePieza(){
    return descripcionDePieza;
}
int Factura::obtenerCantidad(){
    return cantidad;
}
int Factura::obtenerPrecio(){
    return precio;
}
int Factura::obtenerMontoFactura(){
    return cantidad * precio;
}