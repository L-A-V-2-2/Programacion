#include <string>
class Fecha{
    private:
        int mes;
        int dia;
        int anio;
    public:
        Fecha(int, int, int);
        void establecerMes(int);
        void establecerDia(int);
        void establecerAnio(int);  
        
        int obtenerMes();
        int obtenerDia();
        int obtenerAnio();
        void mostrarFecha();
};