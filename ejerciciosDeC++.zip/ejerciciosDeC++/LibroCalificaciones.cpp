#include <iostream>
# include "LibroCalificaciones.h"
using namespace std;
LibroCalificaciones::LibroCalificaciones(string nombre, string instructor):nombreCurso(nombre), nombreInstructor(instructor){

}
void LibroCalificaciones::establecerNombreCurso(string nombre){
    nombreCurso = nombre;
}
string LibroCalificaciones::obtenerNombreCurso() const{
    return nombreCurso;
}
void LibroCalificaciones::establecerNombreInstructor(string nombre){
    nombreInstructor = nombre;
}
string LibroCalificaciones::obtenerNombreInstructor() const{
    return nombreInstructor;
}
void LibroCalificaciones::mostrarMensaje() const{
    cout<<"Bienvenido al libro de calificaciones para "<<obtenerNombreCurso()<<"!"<<endl;
    cout<<"Este curso es presentado por "<<obtenerNombreInstructor()<<"!"<<endl;
}