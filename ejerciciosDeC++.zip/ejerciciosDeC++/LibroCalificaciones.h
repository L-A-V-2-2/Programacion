#include <string>
class LibroCalificaciones{
    public:
        explicit LibroCalificaciones(std::string, std::string);
        void establecerNombreCurso(std::string);
        std::string obtenerNombreCurso() const;
        void establecerNombreInstructor(std::string);
        std::string obtenerNombreInstructor()const;
        void mostrarMensaje() const;
    private:
        std::string nombreCurso;
        std::string nombreInstructor;
};